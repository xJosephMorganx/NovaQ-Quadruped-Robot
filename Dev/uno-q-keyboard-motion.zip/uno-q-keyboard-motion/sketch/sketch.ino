#include <Arduino_RouterBridge.h>
#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

constexpr uint8_t Pca9685Address = 0x40;
constexpr uint8_t ServoFrequencyHz = 50;
constexpr uint8_t FirstServoChannel = 0;
constexpr uint8_t LastServoChannel = 7;
constexpr uint16_t SafePulseMin = 50;
constexpr uint16_t SafePulseMax = 600;
constexpr uint16_t SmoothStepPulse = 5;
constexpr uint16_t SmoothStepDelayMs = 15;
constexpr uint16_t StandShoulderDelayMs = 500;

constexpr uint8_t ChannelShoulderFL = 0;
constexpr uint8_t ChannelLegFL = 1;
constexpr uint8_t ChannelShoulderFR = 2;
constexpr uint8_t ChannelLegFR = 3;
constexpr uint8_t ChannelShoulderBL = 4;
constexpr uint8_t ChannelLegBL = 5;
constexpr uint8_t ChannelShoulderBR = 6;
constexpr uint8_t ChannelLegBR = 7;

struct ServoTarget {
  uint8_t channel;
  uint16_t pulse;
};

const ServoTarget InitialPose[] = {
  {ChannelShoulderFL, 165},
  {ChannelLegFL, 505},
  {ChannelShoulderFR, 390},
  {ChannelLegFR, 90},
  {ChannelShoulderBL, 415},
  {ChannelLegBL, 75},
  {ChannelShoulderBR, 170},
  {ChannelLegBR, 525},
};

const ServoTarget StandShoulders[] = {
  {ChannelShoulderFL, 280},
  {ChannelShoulderFR, 265},
  {ChannelShoulderBL, 285},
  {ChannelShoulderBR, 280},
};

const ServoTarget StandLegs[] = {
  {ChannelLegFL, 110},
  {ChannelLegFR, 500},
  {ChannelLegBL, 495},
  {ChannelLegBR, 110},
};

Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(Pca9685Address);
uint16_t currentPulses[LastServoChannel + 1] = {300, 300, 300, 300, 300, 300, 300, 300};

uint16_t clampPulse(int pulse) {
  if (pulse < SafePulseMin) {
    return SafePulseMin;
  }
  if (pulse > SafePulseMax) {
    return SafePulseMax;
  }
  return static_cast<uint16_t>(pulse);
}

void writeServoPulse(uint8_t channel, uint16_t pulse) {
  uint16_t safePulse = clampPulse(pulse);
  pwm.setPWM(channel, 0, safePulse);
  currentPulses[channel] = safePulse;
}

void moveServoSmooth(uint8_t channel, uint16_t targetPulse) {
  uint16_t safeTarget = clampPulse(targetPulse);
  uint16_t currentPulse = currentPulses[channel];

  while (currentPulse != safeTarget) {
    if (currentPulse < safeTarget) {
      uint16_t nextPulse = currentPulse + SmoothStepPulse;
      currentPulse = nextPulse > safeTarget ? safeTarget : nextPulse;
    } else {
      int nextPulse = static_cast<int>(currentPulse) - SmoothStepPulse;
      currentPulse = nextPulse < safeTarget ? safeTarget : static_cast<uint16_t>(nextPulse);
    }

    writeServoPulse(channel, currentPulse);
    delay(SmoothStepDelayMs);
  }
}

void moveTargetsSmooth(const ServoTarget targets[], size_t targetCount) {
  for (size_t index = 0; index < targetCount; index++) {
    moveServoSmooth(targets[index].channel, targets[index].pulse);
  }
}

String setServoPulse(int channel, int pulse) {
  if (channel < FirstServoChannel || channel > LastServoChannel) {
    return "error: invalid channel";
  }

  writeServoPulse(static_cast<uint8_t>(channel), clampPulse(pulse));
  return "ok";
}

void moveInitial() {
  moveTargetsSmooth(InitialPose, sizeof(InitialPose) / sizeof(InitialPose[0]));
}

void moveStand() {
  moveTargetsSmooth(StandShoulders, sizeof(StandShoulders) / sizeof(StandShoulders[0]));
  delay(StandShoulderDelayMs);
  moveTargetsSmooth(StandLegs, sizeof(StandLegs) / sizeof(StandLegs[0]));
}

String runMotion(String motionName) {
  motionName.trim();
  motionName.toLowerCase();

  if (motionName == "initial") {
    moveInitial();
    return "ok: initial";
  }

  if (motionName == "stand") {
    moveStand();
    return "ok: stand";
  }

  return "error: unknown motion";
}

void setup() {
  Bridge.begin();
  Monitor.begin();

  Wire.begin();
  pwm.begin();
  pwm.setPWMFreq(ServoFrequencyHz);
  delay(10);

  Bridge.provide_safe("set_servo_pulse", setServoPulse);
  Bridge.provide_safe("run_motion", runMotion);

  Monitor.println("UNO Q keyboard motion ready");
}

void loop() {
}
