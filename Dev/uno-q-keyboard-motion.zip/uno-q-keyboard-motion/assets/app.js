const state = {
  poseTable: [],
  lastMotion: "none",
  mjpegMode: false,
  cameraTimer: null,
  motionInFlight: false,
};

const elements = {
  connectionStatus: document.querySelector("#connectionStatus"),
  lastMotion: document.querySelector("#lastMotion"),
  lastResult: document.querySelector("#lastResult"),
  cameraStatus: document.querySelector("#cameraStatus"),
  cameraImage: document.querySelector("#cameraImage"),
  cameraFallback: document.querySelector("#cameraFallback"),
  toggleStreamButton: document.querySelector("#toggleStreamButton"),
  poseRows: document.querySelector("#poseRows"),
  motionButtons: document.querySelectorAll("[data-motion]"),
};

function apiUrl(path) {
  return new URL(path, window.location.origin);
}

async function fetchJson(path, options = {}) {
  const response = await fetch(apiUrl(path), {
    cache: "no-store",
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  let body = null;
  try {
    body = await response.json();
  } catch (_error) {
    body = null;
  }

  if (!response.ok) {
    const detail = body?.error ? `: ${body.error}` : "";
    const error = new Error(`HTTP ${response.status}${detail}`);
    error.status = response.status;
    throw error;
  }

  return body;
}

function setConnectionStatus(text, className) {
  elements.connectionStatus.textContent = text;
  elements.connectionStatus.className = `status-pill ${className}`;
}

function setButtonsDisabled(disabled) {
  elements.motionButtons.forEach((button) => {
    button.disabled = disabled;
  });
}

function renderPoseTable() {
  elements.poseRows.innerHTML = "";
  state.poseTable.forEach((servo) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${servo.name}</td>
      <td>${servo.channel}</td>
      <td>${servo.initial}</td>
      <td>${servo.stand}</td>
    `;
    elements.poseRows.append(row);
  });
}

function renderMotion() {
  elements.lastMotion.textContent = `Motion: ${state.lastMotion}`;
}

async function loadState() {
  try {
    const data = await fetchJson("/api/state");
    state.poseTable = data.poseTable || [];
    state.lastMotion = data.lastMotion || "none";
    elements.lastResult.textContent = data.lastResult || "Ready";
    elements.cameraStatus.textContent = data.camera?.status || "Camera status unknown";
    renderPoseTable();
    renderMotion();
    setConnectionStatus("Connected", "status-success");
  } catch (error) {
    elements.lastResult.textContent = `Connection failed: ${error.message}`;
    setConnectionStatus("Disconnected", "status-danger");
  }
}

async function runMotion(motion) {
  if (state.motionInFlight) {
    return;
  }

  state.motionInFlight = true;
  setButtonsDisabled(true);
  elements.lastResult.textContent = `Running ${motion}...`;
  setConnectionStatus("Sending", "status-warning");

  try {
    const data = await fetchJson("/api/motion", {
      method: "POST",
      body: JSON.stringify({ motion }),
    });

    if (!data.ok) {
      throw new Error(data.error || "Motion command failed");
    }

    state.lastMotion = data.motion;
    elements.lastResult.textContent = data.lastResult || `Motion ${motion} executed`;
    renderMotion();
    setConnectionStatus("Connected", "status-success");
  } catch (error) {
    elements.lastResult.textContent = error.message;
    setConnectionStatus(error.status ? "Request Error" : "Bridge Error", "status-danger");
  } finally {
    state.motionInFlight = false;
    setButtonsDisabled(false);
  }
}

async function refreshCameraFrame() {
  if (state.mjpegMode) {
    return;
  }

  try {
    const data = await fetchJson("/api/camera-frame");
    elements.cameraStatus.textContent = data.status || "Camera status unknown";
    if (!data.ok || !data.available) {
      elements.cameraFallback.classList.remove("hidden");
      return;
    }

    elements.cameraImage.src = `data:${data.mimeType};base64,${data.data}`;
    elements.cameraFallback.classList.add("hidden");
  } catch (error) {
    elements.cameraStatus.textContent = `Camera refresh failed: ${error.message}`;
    elements.cameraFallback.classList.remove("hidden");
  }
}

function startCameraRefresh() {
  if (state.cameraTimer) {
    window.clearInterval(state.cameraTimer);
  }
  state.cameraTimer = window.setInterval(refreshCameraFrame, 250);
  refreshCameraFrame();
}

function toggleStreamMode() {
  state.mjpegMode = !state.mjpegMode;
  if (state.mjpegMode) {
    elements.cameraImage.src = `http://${window.location.hostname}:7001/video-feed`;
    elements.cameraFallback.classList.add("hidden");
    elements.cameraStatus.textContent = "MJPEG stream mode";
    elements.toggleStreamButton.textContent = "Snapshots";
    return;
  }

  elements.toggleStreamButton.textContent = "MJPEG";
  startCameraRefresh();
}

function shouldIgnoreKeyboardEvent(event) {
  const tagName = event.target?.tagName?.toLowerCase();
  return tagName === "input" || tagName === "select" || tagName === "textarea" || event.repeat;
}

elements.motionButtons.forEach((button) => {
  button.addEventListener("click", () => {
    runMotion(button.dataset.motion);
  });
});

window.addEventListener("keydown", (event) => {
  if (shouldIgnoreKeyboardEvent(event)) {
    return;
  }

  const key = event.key.toLowerCase();
  if (key === "i") {
    event.preventDefault();
    runMotion("initial");
  }
  if (key === "s") {
    event.preventDefault();
    runMotion("stand");
  }
});

elements.toggleStreamButton.addEventListener("click", toggleStreamMode);

loadState();
startCameraRefresh();
